#!/bin/sh
openstack server create --flavor m1.tiny --image ubuntu-xenial --security-group custom --key-name Cle --user-data povray-post.sh post-traitement

