#!/bin/sh

#creating container 
openstack container create myContainer
openstack server create --flavor m1.tiny --image ubuntu-xenial --security-group custom --key-name Cle --user-data userdata.sh  povray-instance



