#!/bin/sh

export http_proxy=http://proxy.clermont-universite.fr:8080
apt-get -y install python-openstackclient
#openstack config
export OS_AUTH_URL=http://172.20.88.10:5000/v3
export OS_PROJECT_ID=72fe25d80014433f8bc78a734a5be70b
export OS_PROJECT_NAME="morachidi"
export OS_USER_DOMAIN_NAME="Default"
export OS_USERNAME="morachidi"
export OS_PASSWORD="pheiphohGae8aiFa"
export OS_REGION_NAME="RegionOne"
export OS_INTERFACE=public
export OS_IDENTITY_API_VERSION=3

#Test Config !
openstack server list

#install ImageMagick
apt-get -y install imagemagick

#get images from container
openstack container save myContainer

#create gif file and upload it to myContainer
convert *.png -delay 6 -quality 100 glsbng.gif
openstack object create myContainer glsbng.gif

